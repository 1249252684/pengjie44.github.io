<?php if ( ! defined( 'ABSPATH' ) ) { die; } 
// Q-Q交-流群：9173673-58
// 作者博客：https://www.aj0.cn/
require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
require_once plugin_dir_path(__FILE__) .'options/options.bittheme.php';
require_once plugin_dir_path(__FILE__) .'options/options.bjq.php';
require_once plugin_dir_path(__FILE__) .'options/qzdy_classification.php';
require_once plugin_dir_path(__FILE__) .'options/qzdy_ispage.php';