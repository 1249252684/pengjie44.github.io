<?php
require 'qzdy_fun.php';
// 添加代码请添加在下面
// Q-Q交-流群：9173673-58